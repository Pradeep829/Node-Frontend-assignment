import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
 import UserRegistration from './components/UserRegistration/UserRegistration';
import Organisation from './components/Organisation/Organisation';
import ChatbotIntegration from './components/ChatbotIntegration/ChatbotIntegration';
import TestChatBot from './components/TestChatBtot/TestChatBot';
import "./App.css"
const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<UserRegistration />} />
        <Route path="/organisation" element={<Organisation />} />
        <Route path="/testchatbot" element={<TestChatBot />} />
        <Route path="/chatbot-integration" element={<ChatbotIntegration />} />
      </Routes>
    </Router>
  );
};

export default App;
