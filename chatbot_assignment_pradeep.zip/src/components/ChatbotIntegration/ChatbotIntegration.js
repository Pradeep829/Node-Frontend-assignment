import React, { useState } from 'react';
import Navigation from '../Navigation/Navigation';
import Styles from "./chatbotIntegration.module.css";
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from "framer-motion";

const Chatbot = () => {
    const [messages, setMessages] = useState([]);
    const [userInput, setUserInput] = useState('');

    const handleInputChange = (e) => {
        setUserInput(e.target.value);
    };

    const handleSendMessage = () => {
        if (userInput.trim() !== '') {
            setMessages([...messages, { text: userInput, sender: 'user' }]);
            setTimeout(() => {
                setMessages([
                    ...messages,
                    { text: userInput, sender: 'user' },
                    { text: "I'm a mock chatbot. I received your message: " + userInput, sender: 'bot' },
                ]);
            }, 500);
            setUserInput('');
        }
    };

    return (
        <div className={Styles.chatbot_container}>
            <div className={Styles.message_container}>
                {messages.map((message, index) => (
                    <div key={index} className={`${Styles.message} ${Styles[message.sender]}`}>
                        {message.text}
                    </div>
                ))}
            </div>
            <div className={Styles.input_area}>
                <input
                    type="text"
                    value={userInput}
                    onChange={handleInputChange}
                    placeholder="Type your message..."
                />
                <button onClick={handleSendMessage}>Send</button>
            </div>
        </div>
    );
};

const ChatbotIntegration = () => {
    const navigate = useNavigate();
    const [integrationStatus, setIntegrationStatus] = useState('');
    const [showInstructions, setShowInstructions] = useState(false);
    const [showChatbot, setShowChatbot] = useState(false);

    const handleTestChatbot = () => {
        const link = document.createElement('a');
        link.href = '/testchatbot';
        link.target = '_blank';
        link.click();   
     };

    const handleIntegrateChatbot = () => {
        setShowInstructions(true);
    };

    const handleIntegrationDetected = () => {
        setIntegrationStatus('success');
    };

    const handleBackBtn = () => {
        navigate('/organisation');
    }

    const handleMailInstructions = () => {
        alert("Instructions emailed to developer (mock).");
    };

    const handleStartChatbot = () => {
        setShowChatbot(true);
    };

    return (
        <div className={Styles.chatbot}>
            <Navigation />
            <div className={Styles.chatbot_main}>
                <div className={Styles.chatbot_wrapper}>
                    <div className={Styles.right_wrapper}>
                        <motion.button
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                            onClick={handleTestChatbot}
                            className={Styles.link}
                        >
                            Test Chatbot
                        </motion.button>

                        <div>
                            <motion.button
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                                onClick={handleIntegrateChatbot}
                                className={Styles.link}
                            >
                                Integrate on your Website
                            </motion.button>
                            <AnimatePresence>
                                {showInstructions && (
                                    <motion.div
                                        initial={{ opacity: 0, y: -20 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        exit={{ opacity: 0, y: -20 }}
                                        transition={{ duration: 0.3 }}
                                        className={Styles.integration_options}
                                    >
                                        <h4>Integration Options</h4>
                                        <div className={Styles.integration_option}>
                                            <p className={Styles.copy_paste}>Copy-paste the following code into the &lt;head&gt; of your website:</p>
                                            <pre className={Styles.code_snippet}>
                                                {`<script>
  console.log("Chatbot initialized (mock)");
</script>`}
                                            </pre>
                                        </div>
                                        <div className={Styles.integration_option}>
                                            <button onClick={handleMailInstructions} className={Styles.link}>Mail instructions to developer</button>
                                        </div>
                                        <button onClick={handleIntegrationDetected} className={Styles.link}>Test Integration</button>
                                    </motion.div>
                                )}
                            </AnimatePresence>
                        </div>
                    </div>

                    <div className={Styles.left_wrapper}>
                        <AnimatePresence>
                            {integrationStatus === '' && !showInstructions && (
                                <motion.div
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    exit={{ opacity: 0 }}
                                    transition={{ duration: 0.3 }}
                                >
                                    <h3>Integration Status: Pending</h3>
                                </motion.div>
                            )}
                            {integrationStatus === 'success' && (
                                <motion.div
                                    initial={{ opacity: 0, scale: 0.8 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    exit={{ opacity: 0, scale: 0.8 }}
                                    transition={{ duration: 0.5, type: "spring", stiffness: 100 }}
                                    className={Styles.success_ui}
                                >
                                    <h3>Integration Successful!</h3>
                                    <div className={Styles.confetti}>🎉</div>
                                    <div className={Styles.button_wrapper}>
                                        <motion.button
                                            whileHover={{ scale: 1.05 }}
                                            whileTap={{ scale: 0.95 }}
                                            onClick={() => alert(`Admin panel is opened`)}
                                            className={Styles.link}
                                        >
                                            Explore Admin Panel
                                        </motion.button>
                                        <motion.button
                                            whileHover={{ scale: 1.05 }}
                                            whileTap={{ scale: 0.95 }}
                                            onClick={handleStartChatbot}
                                            className={Styles.link}
                                        >
                                            Start talking to your chatbot
                                        </motion.button>
                                    </div>
                                    {showChatbot && <Chatbot />}
                                    <div className={Styles.social_buttons}>
                                        <button className={Styles.link}>Share on Facebook</button>
                                        <button className={Styles.link}>Share on Twitter</button>
                                    </div>
                                </motion.div>
                            )}
                            {integrationStatus === 'failure' && (
                                <motion.div
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, y: 20 }}
                                    transition={{ duration: 0.3 }}
                                    className={Styles.failure_ui}
                                >
                                    <h3>Integration Not Detected</h3>
                                    <p>Please check your integration code and try again.</p>
                                    <button onClick={() => setIntegrationStatus('')}>Try Again</button>
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </div>
                </div>
                <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleBackBtn}
                    className={Styles.back_btn}
                >
                    Back
                </motion.button>
            </div>
        </div>
    );
};

export default ChatbotIntegration;