import React , {useState}from 'react'
import { useNavigate } from 'react-router-dom'; // For navigation
import Styles from "./navigation.module.css"
function Navigation(props) {
 const [showSettingsPopup, setShowSettingsPopup] = useState(false);
 const navigate = useNavigate();

 const handleUserIconClick = () => {
  setShowSettingsPopup(!showSettingsPopup); 
};

const handleLogout = () => {
  console.log("User logged out.");
  navigate('/'); // Redirect to home
};
  return (
   <div className={Styles.organisation_header}>
   <h2>
    {props.page === "organisation" ? "Setup Organisation": "Chatbot Integration and Testing"} 
   </h2>
   
   {/* User Icon */}
   <div 
     onClick={handleUserIconClick} 
     className={Styles.user_icon}
   >

     {/* Settings Popup */}
     {showSettingsPopup && (
       <div className={Styles.user_modal}>
         <button 
           onClick={handleLogout} 
           className={Styles.logout_btn}
         >
           Logout
         </button>
       </div>
     )}
   </div>
 </div>  )
}

export default Navigation