import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import Styles from "./organisation.module.css";
import Navigation from '../Navigation/Navigation';
import { motion, AnimatePresence } from "framer-motion";

const Organisation = () => {
    const navigate = useNavigate();
    const [companyName, setCompanyName] = useState('');
    const [websiteURL, setWebsiteURL] = useState('');
    const [description, setDescription] = useState('');
    const [webpages, setWebpages] = useState([]);
    const [error, setError] = useState('');
    const [scrapedData, setScrapedData] = useState(null);
    const [selectedPage, setSelectedPage] = useState(null);
    const [loading, setLoading] = useState(false);

    const fetchMetaDescription = (url) => {
        setTimeout(() => {
            setDescription("Mock meta description for " + url);
        }, 500);
    };

    const fetchWebpages = useCallback(() => {
        setLoading(true);
        setTimeout(() => {
            const mockWebpages = [
                { url: `${websiteURL}/page1`, status: 'scraped' },
                { url: `${websiteURL}/page2`, status: 'pending' },
                { url: `${websiteURL}/about`, status: 'pending' },
            ];
            setWebpages(mockWebpages);
            setLoading(false);
        }, 1000);
    }, [websiteURL]);

    const fetchScrapedData = (url) => {
        setSelectedPage(url);
        setTimeout(() => {
            const mockData = {
                title: "Mock Page Title",
                content: "Mock page content. This is some example data.",
                keywords: ["mock", "data", "example"]
            };
            setScrapedData(mockData);
        }, 500);
    };

    useEffect(() => {
        if (websiteURL) {
            fetchMetaDescription(websiteURL);
            fetchWebpages();
        } else {
            setWebpages([]);
        }
    }, [websiteURL, fetchWebpages]);

    const handleNextClick = () => {
        if (!companyName || !websiteURL || !description) {
            setError('Please fill in all the fields.');
            return;
        }
        navigate('/chatbot-integration', { state: { companyName, websiteURL, description } });
    };

    const handleBackClick = () => {
        navigate('/');
    }

    const handleWebsiteURLChange = (e) => {
        setWebsiteURL(e.target.value);
        setError('');
    };

    return (
        <div className={Styles.organisation}>
            <Navigation page={"organisation"} />
            <div className={Styles.next_steps}>
                <div className={Styles.next_steps_main}>
                    <div className={Styles.right_wrapper}>
                        <div>
                            <form>
                                <div className={Styles.input_field}>
                                    <label className={Styles.label}>Company Name</label>
                                    <motion.input
                                        type="text"
                                        placeholder="Company Name"
                                        value={companyName}
                                        onChange={(e) => setCompanyName(e.target.value)}
                                        className={Styles.input}
                                        whileFocus={{ scale: 1.02 }}
                                    />
                                </div>
                                <div className={Styles.input_field}>
                                    <label className={Styles.label}>Company Website URL</label>
                                    <motion.input
                                        type="url"
                                        placeholder="Company Website URL"
                                        value={websiteURL}
                                        onChange={handleWebsiteURLChange}
                                        className={Styles.input}
                                        whileFocus={{ scale: 1.02 }}
                                    />
                                </div>
                                <div className={Styles.input_field}>
                                    <label className={Styles.label}>Company Description</label>
                                    <motion.textarea
                                        placeholder="Company Description"
                                        value={description}
                                        onChange={(e) => setDescription(e.target.value)}
                                        className={Styles.textarea_input}
                                        whileFocus={{ scale: 1.02 }}
                                    />
                                </div>
                                {error && <p className={Styles.error_message} style={{ color: 'red' }}>{error}</p>}
                            </form>
                        </div>
                    </div>
                    <div className={Styles.left_wrapper}>
                        <div className={Styles.detected_webpage}>
                            <h3>Detected Webpages</h3>
                            {loading && <p>Fetching webpages...</p>}
                            <div className={Styles.fetch}>
                                {webpages.map((page, index) => (
                                    <p key={index}>
                                        <div className={Styles.webpage_fetch}>
                                            <p>{page.url}</p> - <p>{page.status}</p>
                                        </div>
                                        {page.status === 'scraped' && (
                                            <motion.button
                                                onClick={() => fetchScrapedData(page.url)}
                                                className={Styles.view_btn}
                                                whileHover={{ scale: 1.05 }}
                                                whileTap={{ scale: 0.95 }}
                                            >
                                                View Scraped Data
                                            </motion.button>
                                        )}
                                    </p>
                                ))}
                            </div>
                        </div>

                        <AnimatePresence>
                            {selectedPage && (
                                <motion.div
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, y: 20 }}
                                    transition={{ duration: 0.3 }}
                                    className={Styles.scraped_data}
                                >
                                    <h3>Scraped Data from: {selectedPage}</h3>
                                    {scrapedData ? (
                                        <pre className={Styles.scraped_data}>{JSON.stringify(scrapedData, null, 2)}</pre>
                                    ) : (
                                        <p className={Styles.loading}>Loading scraped data...</p>
                                    )}
                                </motion.div>
                            )}
                        </AnimatePresence>

                    </div>
                </div>
                <div className={Styles.footer_btn}>
                    <motion.button
                        onClick={handleBackClick}
                        className={Styles.org_btn}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                    >
                        Back
                    </motion.button>
                    <motion.button
                        onClick={handleNextClick}
                        className={Styles.org_btn}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                    >
                        Next
                    </motion.button>
                </div>
            </div>
        </div>
    );
};

export default Organisation;