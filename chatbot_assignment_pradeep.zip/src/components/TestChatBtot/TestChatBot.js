import React, { useState } from 'react';
import Styles from "./testChatbot.module.css";

function TestChatBot() {
    const [showModal, setShowModal] = useState(false);
    const [feedback, setFeedback] = useState('');
    const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);
    const [hasGivenFeedback, setHasGivenFeedback] = useState(false); // Track if feedback has been given

    const handleFeedbackClick = () => {
        if (!hasGivenFeedback) { // Only show modal if feedback hasn't been given
            setShowModal(true);
        }
    };

    const handleCloseModal = () => {
        setShowModal(false);
        setFeedback('');
        setFeedbackSubmitted(false);
    };

    const handleInputChange = (e) => {
        setFeedback(e.target.value);
    };

    const handleSubmit = () => {
        if (feedback.trim() !== '') {
            setFeedbackSubmitted(true);
            setHasGivenFeedback(true); // Prevent further feedback
            console.log("Feedback submitted:", feedback);
            setTimeout(handleCloseModal, 2000);
        } else {
            alert("Please enter some feedback");
        }
    };

    return (
        <div className={Styles.test_chatbot_main}>
            <div className={Styles.chatbot_wrapper}>
                Chatbot not working as intended?{" "}
                <p
                    className={`${Styles.feedback_link} ${hasGivenFeedback ? Styles.feedback_given : ''}`} // Add class if feedback given
                    onClick={handleFeedbackClick}
                >
                    {hasGivenFeedback ? "Feedback Submitted" : "Share feedback"} {/* Show different text */}
                </p>
            </div>

            {showModal && (
                <div className={Styles.modal}>
                    <div className={Styles.modal_content}>
                        <span className={Styles.close_icon} onClick={handleCloseModal}>
                            &times;
                        </span>
                        <h2 className={Styles.share_feedback}>Share Feedback</h2>
                        {!feedbackSubmitted ? (
                            <div className={Styles.feedback_button_wrapper}>
                                <input
                                    type="text"
                                    value={feedback}
                                    onChange={handleInputChange}
                                    placeholder="Enter your feedback here..."
                                    className={Styles.feedback_input}
                                />
                                <button onClick={handleSubmit} className={Styles.submit_button}>
                                    Submit
                                </button>
                            </div>
                        ) : (
                            <p>Thank you for your feedback!</p>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}

export default TestChatBot;